import React from 'react';
import './App.css'; // Import your main CSS file
import EventDetails from './components/EventDetails'; // Import the EventDetails component
import Navbar from './components/NavBar'; // Import the Navbar component
import Footer from './components/Footer'; // Import the Footer component
import { BrowserRouter } from 'react-router-dom'; // Import BrowserRouter
import Jumbotron from './components/Jumbotron';
import EventCard from './components/EventCard';
import event2 from './assets/event2.jpg'



function App() {
  return (
    <BrowserRouter>
      <div className="App">
        <header className="App-header">
          <Navbar />
          <h1>ONE ZERO EVENTS</h1>
        </header>
        <main className="App-content">
          <div className="card-grid">
            {/* Card 1: Upcoming Events */}
            <EventCard
              title="Upcoming Events"
              description="Explore our upcoming events"
              imageSrc="/images/event1.webp"
              buttonText="View Upcoming Events"
              className="card"
            />

            {/* Card 2: Past Events */}
            <EventCard
              title="Past Events"
              description="Browse our past events"
              imageSrc="https://example.com/past-events-image.jpg"
              buttonText="View Past Events"
              className="card"
            />

            {/* Card 3: Become a Promoter */}
            <EventCard
              title="Become a Promoter"
              description="Join our promoter program"
              imageSrc="https://example.com/promoter-image.jpg"
              buttonText="Learn More"
              className="card"
            />
          </div>
        </main>
        <Footer />
      </div>
    </BrowserRouter>
  );
}

export default App;
