import React from 'react';
import { Link } from 'react-router-dom';

function Footer() {
  return (
    <footer className="flex flex-col items-center bg-neutral-900 text-center text-white">
      <div className="container px-6 pt-6">
        <div className="mb-6 flex justify-center">
          <a
            href="#!"
            type="button"
            className="m-1 h-9 w-9 rounded-full border-2 border-white uppercase leading-normal text-white transition duration-150 ease-in-out hover:bg-black hover:bg-opacity-5 focus:outline-none focus:ring-0"
            data-te-ripple-init
            data-te-ripple-color="light"
          >
            {/* Replace this comment with your first SVG icon */}
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="mx-auto h-full w-4"
              fill="currentColor"
              viewBox="0 0 24 24"
            >
              {/* Include your SVG path here */}
            </svg>
          </a>
          {/* Add similar anchor elements for other icons */}
        </div>
      </div>

      {/* Copyright section */}
      <div
        className="w-full p-4 text-center"
        style={{ backgroundColor: 'rgba(0, 0, 0, 0.2)' }}
      >
        © 2023 Copyright:
        <br></br>
        <a className="text-white" href="https://mytickets.lk/">
          ONE ZERO EVENTS
        </a>
      </div>
    </footer>
  );
}

export default Footer;
