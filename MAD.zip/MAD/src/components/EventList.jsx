import React from 'react';

const EventList = ({ events, onEventClick }) => {
  return (
    <div>
      <h1>Upcoming Events</h1>
      <ul>
        {events.map((event) => (
          <li key={event.id}>
            <button onClick={() => onEventClick(event.id)}>
              {event.title}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default EventList;
