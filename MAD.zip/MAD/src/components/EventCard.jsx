import React from 'react';

function EventCard({ title, description, imageSrc, buttonText }) {
  return (
    <div className="event-card">
      <img src={imageSrc} alt={title} />
      <h2>{title}</h2>
      <p>{description}</p>
      <button>{buttonText}</button>
    </div>
  );
}

export default EventCard;
